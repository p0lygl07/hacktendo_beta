
import sys
import time

def run_mission():
    print("\n\033[91m[!!!] OMNICORP INTEL ACQUIRED [!!!]\033[0m")
    time.sleep(0.5)
    print(">> Decrypting Director Thorne's personal comms...")
    time.sleep(1.0)
    print(">> THORNE: 'The Rebel Cell is getting too close to Sector 7. Double the traces.'")
    print(">> THORNE: 'If they find out Project Nebula is a neural overwrite, the board will hang us.'")
    print("\n\033[92m[+] MISSION COMPLETE. FLAG GENERATED.\033[0m")
    print("\033[93m[ FLAG{THORNE_OVERWRITE_0042} ]\033[0m\n")

if __name__ == "__main__":
    run_mission()
